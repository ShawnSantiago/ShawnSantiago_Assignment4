$.fn.settings = function(options) {

	var settings = $.extend({
		color:"#0000ff",
		lineHeight:"32px",
		fontSize:"24px"
	}, options);

	return this.css({
		color: settings.color,
		lineHeight: settings.lineHeight,
		fontSize: settings.fontSize
	});
};