$(document).ready(function() {

	//Create function called greenify
	$.fn.greenify = function () {
		
		// Change colour of text to green
		this.css("color","green");
		//Return the value
		return this;
	}

	$('h1').greenify();

	$('.lightbox_trigger').lightbox();
	$('p').settings({
		color:"#ff0000",
		fontSize:"25px"
	});
});